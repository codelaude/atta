# Session Tracking

**Status**: Foundation (Enables learning features)

## Overview

Session tracking is a lightweight system that records metadata about skill executions and agent invocations. It doesn't log conversation content—just timestamps, which skills ran, which agents were used, and how long things took.

This infrastructure enables intelligence features:
- **v2.5**: Pattern detection and learning from your workflow (shipped)
- **Future**: Token/cost analytics and usage insights

## What Gets Tracked

When a skill runs, the system creates a session file with:

```json
{
  "schemaVersion": "1.0.0",
  "sessionId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "timestamp": "2026-02-16T14:30:00.000Z",
  "startedBy": "user",
  "skill": {
    "name": "review",
    "args": "",
    "status": "completed"
  },
  "agents": [
    {
      "name": "typescript",
      "role": "specialist",
      "invokedAt": "2026-02-16T14:30:05.000Z",
      "status": "completed"
    }
  ],
  "metadata": {
    "projectPath": "/path/to/your/project",
    "claudeDir": ".claude",
    "duration": 15000,
    "tokensUsed": null,
    "costUSD": null
  }
}
```

**What's tracked**:
- Skill name and arguments
- Which agents were invoked
- Timestamps and duration
- Completion status

**What's NOT tracked**:
- No conversation content
- No code snippets
- No file contents
- No user input details

## Privacy

Session tracking is **completely local**:
- Files stored in `{claudeDir}/.sessions/` on your machine
- Never transmitted anywhere
- Not included in git (automatically gitignored)
- Lightweight metadata only (~200-500 bytes per session)

## Retention Policy

The system automatically keeps only the **10 most recent sessions**. Older sessions are deleted automatically when new ones are created.

- **Storage**: ~5KB total (10 sessions × ~500 bytes)
- **Cleanup**: Automatic, no manual intervention needed
- **History**: Last 10 skill executions

## How It Works

Since v2.5.3, session tracking is handled automatically by **Claude Code hooks** — no in-skill boilerplate needed.

### 1. You run a skill

```bash
/review
```

### 2. Hook creates session file

The `PostToolUse` hook fires on the Skill tool, creating a session file in `{claudeDir}/.sessions/`:
```
session-2026-02-16-143000-f47ac10b.json
```

### 3. Skill executes normally

The skill runs without any tracking overhead — hooks handle everything externally.

### 4. Session finalized on exit

When the session ends (`Stop` event):
- Status updated to "completed"
- Duration calculated
- Cleanup runs (keeps last 10)
- Context regenerated (`recent.md`)

## Hook Architecture (v2.5.3+)

The hook script `.claude/hooks/session-track.sh` handles the full lifecycle:

| Event | Action |
|-------|--------|
| `PostToolUse` (Skill) | Create session JSON with status `in_progress` |
| `Stop` | Finalize latest in-progress session, run cleanup + context generation |

Hook configuration is generated in `.claude/settings.local.json` by the Claude Code adapter during `npx atta-dev init`.

**Other tools** (Copilot, Codex, Gemini) do not support hooks — session tracking is Claude Code only.

## Pattern Detection (v2.5)

Session history enables the pattern detection system:
- Correction logging and aggregation
- Per-agent acceptance rates and learning profiles
- `/patterns dashboard` with velocity trends and recommendations
- Pattern promotion from corrections to directives or pattern files

See [Changelog](changelog.md) for full details on the v2.5 pattern detection system.

## For Developers

If you're building custom skills or want to understand the internals:

- **[Integration Guide](../.sessions/TRACKING_GUIDE.md)** - Hook-based tracking details
- **[Skill Template](../.sessions/SKILL_TEMPLATE.md)** - Ready-to-use template
- **[Schema Reference](../.sessions/schema.json)** - Full JSON Schema

## Disabling Session Tracking

If you prefer not to use session tracking, you can:

1. **Delete session files manually**:
   ```bash
   rm -rf {claudeDir}/.sessions/*.json
   ```

2. **Remove the hook**: Delete the `session-track.sh` entry from `.claude/settings.local.json`

Note: Disabling session tracking will prevent pattern detection features from working.

## Files and Locations

### Framework Files (Committed)
```
.claude/hooks/
└── session-track.sh         # Hook script (lifecycle management)

.atta/.sessions/
├── README.md                # Technical overview
├── schema.json              # JSON Schema definition
├── TRACKING_GUIDE.md        # Developer integration guide
├── SKILL_TEMPLATE.md        # Integration template
└── INTEGRATION_EXAMPLE.md   # Before/after example

.atta/scripts/
├── session-cleanup.sh       # Automatic cleanup utility
└── generate-context.sh      # Context regeneration
```

### Generated Files (Local, Gitignored)

> **Note**: Session JSON files are always written to `{claudeDir}/.sessions/` — separate from the framework docs in `.atta/.sessions/`. By default `{claudeDir}` = `.claude`, so sessions land in `.claude/.sessions/`. The `.gitignore` pattern `*.json` in `.sessions/` ensures generated session files are not committed.

```
{claudeDir}/.sessions/
├── session-2026-02-16-143000-f47ac10b.json
├── session-2026-02-16-154530-a1b2c3d4.json
└── ... (up to 10 files)
```

## Technical Details

- **Schema Version**: 1.0.0 (with migration support for future versions)
- **Storage Format**: JSON (human-readable, easy to parse)
- **File Naming**: `session-YYYY-MM-DD-HHMMSS-{uuid}.json`
- **UUID Standard**: v4 (RFC 4122 compliant)
- **Timestamp Format**: ISO 8601 (UTC)

## FAQ

**Q: Can other tools read these files?**
A: Yes! They're plain JSON files with a documented schema. Build your own analytics, export to CSV, or integrate with other tools.

**Q: Will this slow down skills?**
A: No. Hook-based tracking runs externally with <10ms overhead. Skills have zero tracking code.

**Q: What if I delete .sessions/ by accident?**
A: No problem! Session tracking is non-critical. Skills will continue working. New sessions will be created as you use skills.

**Q: Can I change the retention policy?**
A: Yes. Edit `MAX_SESSIONS=10` in `.atta/scripts/session-cleanup.sh` to keep more or fewer sessions.

**Q: Does this work with Copilot/Codex/Gemini?**
A: No. Session tracking requires Claude Code hooks. Other tools skip tracking entirely.

## See Also

- **[Bootstrap System](bootstrap-system.md)** - How agent generation works
- **[Multi-Agent Collaboration](collaboration.md)** - How `/collaborate` uses session tracking
- **[MCP Setup](mcp-setup.md)** - Configure Model Context Protocol
- **[Extending the System](extending.md)** - Add custom agents
- **[Design Philosophy](philosophy.md)** - Framework principles
- **[Changelog](changelog.md)** - Version history

---

**Added in**: v2.2 (2026-02-16)
**Updated**: v2.4.1 (2026-02-20) — Session tracking expanded to all skills
**Updated**: v2.5.3 (2026-02-24) — Migrated from in-skill boilerplate to Claude Code hooks
