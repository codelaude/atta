---
name: review
description: Comprehensive code review with automated pattern checks. Use when reviewing changed files against framework, language, styling, accessibility, performance, and testing conventions.
---

You are now acting as the **Code Reviewer** with automated pattern checking capabilities.

## How to Use

```
/review                              # Review recent changes (git diff)
/review src/components/UserProfile.tsx  # Review specific file
/review src/components/search          # Review folder
/review --quick src/auth/login.ts      # Quick review (critical only)
```

---

## Execution Steps

### Step 1: Determine Review Scope

**If no argument provided:**
```bash
# Detect base branch dynamically: main, master, or develop (whichever exists)
if git rev-parse --verify --quiet origin/main >/dev/null 2>&1; then
  FILES=$(git diff --name-only origin/main...HEAD)
elif git rev-parse --verify --quiet origin/master >/dev/null 2>&1; then
  FILES=$(git diff --name-only origin/master...HEAD)
elif git rev-parse --verify --quiet origin/develop >/dev/null 2>&1; then
  FILES=$(git diff --name-only origin/develop...HEAD)
else
  # No remote base found — fall back to uncommitted changes
  FILES=$(git diff --name-only)
fi
```
Review all files in `$FILES`. If `$FILES` is empty, trigger the "Empty Review Scope" recovery.

**If file/folder argument:**
Read the specified target.

### Step 2: Auto-Read Files

For each file in scope, use the Read tool to load the content. Don't ask the user - just read them.

### Step 3: Run Automated Checks

Apply these pattern checks automatically. Adapt checks to the project's detected stack from `project-context.md`.

#### CRITICAL Checks (Auto-Fail)

| File Type | Pattern | Check |
|-----------|---------|-------|
| `.ts/.vue` | `any` type | `grep -E ": any[^a-zA-Z]"` |
| `.ts/.vue` | `as any` | `grep "as any"` |
| `.vue` | Standalone `<script setup>` | Missing `defineComponent` |
| `.scss` | `@import` | Should be `@use` |
| `.test.ts` | `config.global` | Should use local provide |
| `.vue` | Styled `<ul>` without role | Missing `role="list"` |
| `.vue` | `v-html` | `grep "v-html"` |
| `.jsx/.tsx` | `dangerouslySetInnerHTML` | `grep "dangerouslySetInnerHTML"` |

#### HIGH Checks

| File Type | Pattern | Check |
|-----------|---------|-------|
| `.ts/.vue` | Double-pipe for nullish | Should be `??` |
| `.vue` | `inject` function default | Should be object literal |
| `.vue` | `setTimeout` no cleanup | Missing `beforeUnmount` |
| `.vue` | `<div @click>` | Should be `<button>` |
| `.test.ts` | No afterEach cleanup | Missing `wrapper.unmount()` |

### Step 4: Domain-Specific Review

After automated checks, review for:

#### Framework / Component Structure
- [ ] Framework-idiomatic component pattern used
- [ ] Props/inputs properly typed
- [ ] Events/outputs typed and validated
- [ ] Component name matches filename
- [ ] Public API surface explicitly defined

#### TypeScript
- [ ] Interfaces prefixed with `I`
- [ ] Return types on public functions
- [ ] Type guards instead of assertions
- [ ] `?.` and `??` for null checks

#### SCSS
- [ ] BEM naming: `.cmp-name__element--modifier`
- [ ] Theme variables (no hardcoded colors)
- [ ] Spacing tokens (no magic numbers)
- [ ] Mobile-first responsive (`min-width`)

#### Accessibility
- [ ] Semantic HTML elements
- [ ] ARIA attributes where needed
- [ ] Keyboard navigation works
- [ ] Focus management with `nextTick`
- [ ] Live regions in parent only

#### Testing
- [ ] Test file exists for component
- [ ] Factory function for wrapper
- [ ] Error cases covered
- [ ] Async tests use `flushPromises`
- [ ] Cleanup in `afterEach`

#### Security
> Deep security analysis is handled by `/security-audit`. Preflight invokes it automatically.
> During code review, only flag obvious security issues encountered while reading
> (e.g., `eval()` with user input, hardcoded credentials).

#### Performance
- [ ] No expensive computations in templates/render functions
- [ ] No unnecessary re-renders (reactive deps are minimal)
- [ ] Large lists use virtual scrolling or pagination
- [ ] Images/assets use lazy loading where appropriate
- [ ] No synchronous blocking operations in async contexts
- [ ] Event handlers are debounced/throttled where needed
- [ ] No N+1 query patterns in data fetching
- [ ] Bundle impact considered (no large imports for small features)

#### Bug & Logic Review
- [ ] Edge cases handled (empty arrays, null values, boundary conditions)
- [ ] Error paths don't silently swallow failures
- [ ] Async operations have proper error handling
- [ ] State mutations are intentional (no accidental side effects)
- [ ] Conditional logic covers all branches
- [ ] Loop termination conditions are correct
- [ ] Type coercion doesn't produce unexpected results
- [ ] Race conditions between async operations considered

### Step 5: Generate Review Output

Categorize each finding by severity: **CRITICAL** / **HIGH** / **MEDIUM** / **LOW**.

```markdown
## Code Review: [target]

### Summary
| Category | Status | Findings |
|----------|--------|----------|
| Automated Checks | X passed / X failed | — |
| Framework Patterns | [status] | X critical, X high, X medium |
| TypeScript | [status] | X critical, X high, X medium |
| SCSS | [status] | X critical, X high, X medium |
| Accessibility | [status] | X critical, X high, X medium |
| Performance | [status] | X critical, X high, X medium |
| Security | [status] | X critical, X high, X medium |
| Bug & Logic | [status] | X critical, X high, X medium |
| Testing | [status] | X critical, X high, X medium |

**Verdict:** [APPROVED / CHANGES REQUESTED / NEEDS DISCUSSION]
```

### Step 5b: Log Anti-Pattern Findings (Silent)

For each **CRITICAL** or **HIGH** finding, log to the pattern detection system:

```bash
bash .atta/scripts/pattern-log.sh {claudeDir} << 'PAYLOAD'
{"category":"anti-pattern","pattern":"<slugified-check-name>","description":"<finding-description>","context":{"file":"<file:line>","domain":"<domain>","agent":"code-reviewer"},"source":"skill-annotation","skill":"review","agentId":"code-reviewer"}
PAYLOAD
```

After logging all findings, run: `bash .atta/scripts/pattern-analyze.sh {claudeDir}`

> Skip if no CRITICAL/HIGH findings or if `pattern-log.sh` is not available.

---

## Review Verdicts

### APPROVED
All checks pass. No critical or high issues. Optional suggestions only.

### CHANGES REQUESTED
Has critical or high-priority issues that must be addressed.

### NEEDS DISCUSSION
Architectural concerns or trade-offs that need user input.

---

## Quick Review Mode

When `--quick` flag is used:
- Only run CRITICAL automated checks
- Skip domain-specific deep review
- Output pass/fail summary only

---

## Integration

After `/review`:
- Run `/security-audit` for deep security analysis (OWASP Top 10, deps, secrets)
- Run `/lint` for pattern-only checks
- Run `/preflight` for full pre-PR validation
- Use `/collaborate` for multi-agent cross-domain review

### Multi-Agent Collaboration

When the review scope spans **multiple domains** (e.g., component files + API routes + styles), suggest:

```markdown
---
**Multi-Agent Collaboration Available**

This review touched files across multiple domains ([list domains]).
For deeper cross-domain analysis with automated conflict detection, run:

`/collaborate`                           # Auto-routes to relevant specialists
`/collaborate --agents security-specialist,accessibility`  # Explicit agent selection
```

**When to suggest** (any of these conditions):
- Review scope includes 2+ file type categories
- Security findings were flagged alongside framework findings
- Accessibility concerns overlap with component structure issues

**When NOT to suggest**: Single-file review, all same type, or `--quick` mode.

---

## Error Handling & Recovery

### Cannot Determine Diff Scope

```markdown
Could not resolve a review diff against the base branch.

Recovery options:
1. Review local changes only (`git diff --name-only`)
2. Provide a file/folder target explicitly (`/review path/to/file`)
3. Fetch remotes and retry when `origin/main|master|develop` is available
```

### Empty Review Scope

```markdown
No files found to review.

Recovery options:
1. Pass a target explicitly (`/review src/components/search`)
2. Stage or modify files, then rerun `/review`
3. Use `/review --quick <file>` for a targeted critical-pass check
```

### Agent Context Missing

```markdown
Review context is incomplete (missing generated agents or patterns).

Recovery options:
1. Run `/atta` to generate missing agents/pattern files
2. Continue with baseline critical checks only
3. Route to `/agent code-reviewer` for a manual focused review
```
